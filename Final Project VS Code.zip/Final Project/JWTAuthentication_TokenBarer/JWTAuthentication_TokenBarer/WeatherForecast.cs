using System;

namespace JWTAuthentication_TokenBarer
{
    public class WeatherForecast
    {
        public int CarNumber { get; internal set; }
        public int Speed { get; internal set; }
        public string CarName { get; internal set; }
    }
}
