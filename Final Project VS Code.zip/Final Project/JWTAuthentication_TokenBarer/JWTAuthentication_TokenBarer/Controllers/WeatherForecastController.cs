﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace JWTAuthentication_TokenBarer.Controllers
{
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [ApiController]
    [Route("[controller]")]

    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Mercedes", "Lamborghini", "Toyota", "Honda", "Jeep", "Ford", "Mahindra", "Duke", "Kawasaki", "Nano"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<WeatherForecast> Get()
        {
            var rng = new Random();
            var cn = new Random();
            return Enumerable.Range(1, 10).Select(index => new WeatherForecast
            {
                Speed = rng.Next(0, 400),
                CarName = Summaries[rng.Next(Summaries.Length)],
                CarNumber = cn.Next(1324, 1560)
            })
            .ToArray();
        }
    }
}
